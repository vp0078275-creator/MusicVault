package com.vault.music2

import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager

class CalculatorActivity : AppCompatActivity() {

    private lateinit var tvExpression: TextView
    private lateinit var tvResult: TextView
    private var inputExpression = ""

    private lateinit var sharedPreferences: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculator)

        tvExpression = findViewById(R.id.tvExpression)
        tvResult = findViewById(R.id.tvResult)

        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)

        // Default PIN agar set na ho toh "1234" rahega
        if (!sharedPreferences.contains("vault_pin")) {
            sharedPreferences.edit().putString("vault_pin", "1234").apply()
        }

        setupKeypad()
    }

    private fun setupKeypad() {
        val buttons = listOf(
            R.id.btn0 to "0", R.id.btn1 to "1", R.id.btn2 to "2",
            R.id.btn3 to "3", R.id.btn4 to "4", R.id.btn5 to "5",
            R.id.btn6 to "6", R.id.btn7 to "7", R.id.btn8 to "8",
            R.id.btn9 to "9"
        )

        for ((id, value) in buttons) {
            findViewById<Button>(id).setOnClickListener { appendOnExpression(value) }
        }

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            inputExpression = ""
            tvExpression.text = ""
            tvResult.text = "0"
        }

        findViewById<Button>(R.id.btnEquals).setOnClickListener {
            evaluateResult()
        }
    }

    private fun appendOnExpression(string: String) {
        inputExpression += string
        tvExpression.text = inputExpression
    }

    private fun evaluateResult() {
        val savedPin = sharedPreferences.getString("vault_pin", "1234")

        // Agar entered input saved PIN se match ho jaye, toh Settings/Vault khul jayega
        if (inputExpression == savedPin) {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
            inputExpression = ""
            tvExpression.text = ""
            tvResult.text = "0"
            return
        }

        // Simple evaluation ya default calculation logic
        try {
            // Yahan basic calculation ya fallback result dikha sakte hain
            tvResult.text = inputExpression
        } catch (e: Exception) {
            tvResult.text = "Error"
        }
    }
}
